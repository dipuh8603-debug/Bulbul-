package com.example.personalassistant

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.URLEncoder
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val micRequest = 201
    private val speechRequest = 202

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFFF7F8FC.toInt())
        }
        val title = TextView(this).apply {
            text = "আমার AI সহকারী"
            textSize = 28f
            setTextColor(0xFF18213A.toInt())
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "মাইক্রোফোনে চাপ দিয়ে বাংলায় নির্দেশ দিন।\n\nউদাহরণ: ‘ক্রোমে বিড়াল সার্চ করো’, ‘ফেসবুক খোলো’, ‘ওয়ার্ডপ্রেস খোলো’।"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(0xFF384152.toInt())
            setPadding(0, 24, 0, 24)
        }
        status = TextView(this).apply {
            text = "প্রস্তুত"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF3157D5.toInt())
            setPadding(0, 8, 0, 18)
        }
        val mic = Button(this).apply {
            text = "🎙 কথা বলুন"
            textSize = 18f
            setOnClickListener { listen() }
        }
        val chrome = Button(this).apply {
            text = "Chrome খুলুন"
            setOnClickListener { openUrl("https://www.google.com", "Chrome/Google খুলছি।") }
        }
        val facebook = Button(this).apply {
            text = "Facebook খুলুন"
            setOnClickListener { openFacebook() }
        }
        val wordpress = Button(this).apply {
            text = "WordPress খুলুন"
            setOnClickListener { openUrl("https://bikroyo.com/wp-admin/", "WordPress লগইন পেজ খুলছি।") }
        }
        listOf(title, info, status, mic, chrome, facebook, wordpress).forEach { view ->
            root.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = if (view is Button) 8 else 0
            })
        }
        setContentView(root)
    }

    private fun listen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "আপনার নির্দেশ বলুন")
        }
        try {
            startActivityForResult(intent, speechRequest)
        } catch (_: ActivityNotFoundException) {
            say("এই ফোনে ভয়েস টাইপিং সেবা পাওয়া যাচ্ছে না। Google অ্যাপ বা Speech Services আপডেট করুন।")
        }
    }

    @Deprecated("Android speech-recognition activity result API used for starter simplicity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            status.text = "আপনি বলেছেন: $spoken"
            handleCommand(spoken)
        }
    }

    private fun handleCommand(raw: String) {
        val s = raw.lowercase(Locale.ROOT)
        when {
            s.contains("সার্চ") || s.contains("খুঁজে") || s.contains("search") -> {
                val query = raw.replace(Regex("(?i)ক্রোমে|গুগলে|সার্চ করো|সার্চ|খুঁজে দাও|খুঁজে বের করো|খুঁজে দেখো|please"), " ").trim()
                if (query.isBlank()) {
                    say("কী সার্চ করব বলুন।")
                } else {
                    val encoded = URLEncoder.encode(query, "UTF-8")
                    openUrl("https://www.google.com/search?q=$encoded", "$query সার্চ করছি।")
                }
            }
            s.contains("ফেসবুক") || s.contains("facebook") -> openFacebook()
            s.contains("ওয়ার্ডপ্রেস") || s.contains("wordpress") -> openUrl("https://bikroyo.com/wp-admin/", "WordPress লগইন পেজ খুলছি। লগইন আপনাকেই করতে হবে।")
            s.contains("ক্রোম") || s.contains("chrome") || s.contains("ব্রাউজার") -> openUrl("https://www.google.com", "Google খুলছি।")
            s.contains("বন্ধ") || s.contains("থামো") -> say("ঠিক আছে। এই প্রাথমিক সংস্করণে আমি আর কোনো কাজ শুরু করছি না।")
            else -> say("এই নির্দেশটি এখনো বুঝতে শিখিনি। আপাতত Chrome, সার্চ, Facebook ও WordPress-এর নির্দেশ দিতে পারেন।")
        }
    }

    private fun openFacebook() {
        val launch = packageManager.getLaunchIntentForPackage("com.facebook.katana")
        if (launch != null) {
            startActivity(launch)
            say("Facebook খুলছি।")
        } else {
            openUrl("https://www.facebook.com", "Facebook ওয়েবসাইট খুলছি।")
        }
    }

    private fun openUrl(url: String, message: String) {
        say(message)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            status.text = "কোনো ব্রাউজার পাওয়া যায়নি।"
        }
    }

    private fun say(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "assistant-message")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("bn", "BD")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
        else if (requestCode == micRequest) say("ভয়েস নির্দেশের জন্য মাইক্রোফোনের অনুমতি দরকার।")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
